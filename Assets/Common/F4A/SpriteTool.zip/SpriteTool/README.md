# SpriteTool
This is a free sprite tool for Unity 2D
Use this tool to quickly generate new GameObject with animations 
based on sample GameObject

New GameObject needs to have a similar sprites/sprite sheet as sample GameObject

HOW TO USE: 
a. To slice prite sheets:
Fill in basic settings for the sprite sheet, along with the sprite sheet texture2D (this tool will slice the prite sheet into sprite based on the settings)
b. To generate animations: 
This needs the sliced spited in part a, and a sample GameObject with animations to based on. 
c. To generate GameObject prefabs:
Complete part a and b.

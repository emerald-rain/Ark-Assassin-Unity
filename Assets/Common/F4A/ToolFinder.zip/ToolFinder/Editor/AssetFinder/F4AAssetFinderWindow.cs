//using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Text;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEditorInternal;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace com.F4A.ToolFinder
{
	public enum TypeAssetFinder{
		Prefab,
		Scene,
	}
    [InitializeOnLoad]
    public class F4AAssetFinderWindow : EditorWindow
    {
        public Object findAsset;

        private bool isSerilizedField = false, isHiddenField = false, isProperties = false;
        private bool isPrefab = false, isScene = false;

        [MenuItem("F4A/Finder Tools/F4A Asset Finder", priority = 1330)]
        public static void Open()
        {
            GetWindow(typeof(F4AAssetFinderWindow), true, "F4A Asset Finder Window", false);
        }
		
		protected virtual void OnGUI()
		{
            if (GUILayout.Button("Search References"))
            {
                SearchReferences();
            }
            EditorGUILayout.BeginHorizontal(new GUILayoutOption[] { });
            GUILayout.Label("Find Asset", GUILayout.MaxWidth(100));
            findAsset = EditorGUILayout.ObjectField("", findAsset, typeof(Object), true, GUILayout.Width(300), GUILayout.MinWidth(200)) as Object;
            EditorGUILayout.EndHorizontal();

            EditorGUILayout.BeginHorizontal(new GUILayoutOption[] { });
            GUILayout.Label("Search Option: ", GUILayout.MaxWidth(100));
            isSerilizedField = GUILayout.Toggle(isSerilizedField, "Serialized Field", "Button");
            isHiddenField = GUILayout.Toggle(isHiddenField, "Hidden Field", "Button");
            isProperties = GUILayout.Toggle(isProperties, "Properties", "Button");
            EditorGUILayout.EndHorizontal();

            EditorGUILayout.BeginHorizontal(new GUILayoutOption[] { });
            GUILayout.Label("Search In: ", GUILayout.MaxWidth(100));
            isPrefab = GUILayout.Toggle(isPrefab, "Prefab", "Button");
			isScene = GUILayout.Toggle(isScene, "Scene", "Button");
            EditorGUILayout.EndHorizontal();
        }

        protected void SearchReferences()
        {
            AssetDatabase.GetAssetPath(findAsset);
			List<TypeAssetFinder> typeAssets = new List<TypeAssetFinder> ();
			if (isPrefab)
				typeAssets.Add (TypeAssetFinder.Prefab);
			if (isScene)
				typeAssets.Add (TypeAssetFinder.Scene);
			var assets = GetAllAssets ("Assets", typeAssets);
			Debug.Log (assets.Count);
        }

		private static List<GameObject> GetAllAssets(string path, List<TypeAssetFinder> typeAssets)
        {
            string[] paths = { path };
			List<string> assets = new List<string> ();
			string fillter = "";
			if (typeAssets.Contains (TypeAssetFinder.Prefab))
				fillter += "t:Prefab";
			if (typeAssets.Contains (TypeAssetFinder.Scene))
				fillter += " t:scene";
			if(!string.IsNullOrEmpty(fillter))
				assets = AssetDatabase.FindAssets (fillter, paths).ToList();
			
            var assetsObj = assets.Select(s => AssetDatabase.LoadAssetAtPath<GameObject>(AssetDatabase.GUIDToAssetPath(s))).ToList();
            return assetsObj;
        }
    }
}
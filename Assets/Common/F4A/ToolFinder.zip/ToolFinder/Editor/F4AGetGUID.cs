﻿using UnityEditor;
using UnityEngine;

namespace com.F4A.ToolFinder
{
    public class F4AGetGUID : EditorWindow
    {
        private string guid = "";
        private Object findAsset;

        [MenuItem("F4A/Finder Tools/F4A Get GUID", priority = 1330)]
        public static void Open()
        {
            GetWindow(typeof(F4AGetGUID), true, "F4A Get GUID", false);
        }

        protected virtual void OnGUI()
        {
            if (GUILayout.Button("Get GUID"))
            {
                GetGUID();
            }

            EditorGUILayout.TextField(guid);
            EditorGUILayout.BeginHorizontal(new GUILayoutOption[] { });
            GUILayout.Label("Find Asset", GUILayout.MaxWidth(100));
            findAsset = EditorGUILayout.ObjectField("", findAsset, typeof(Object), true, GUILayout.Width(300), GUILayout.MinWidth(200)) as Object;
            EditorGUILayout.EndHorizontal();
        }

        private void GetGUID()
        {
            guid = AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(findAsset));
        }
    }
}